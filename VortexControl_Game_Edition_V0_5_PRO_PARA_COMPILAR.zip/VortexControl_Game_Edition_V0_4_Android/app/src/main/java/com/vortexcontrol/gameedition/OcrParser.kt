package com.vortexcontrol.gameedition

object OcrParser {
    data class Values(val speed: Int? = null, val rpm: Int? = null, val gear: Int? = null) {
        val any: Boolean get() = speed != null || rpm != null || gear != null
    }

    fun parse(raw: String): Values {
        val lines = raw.lines().map { it.trim().replace(',', '.') }.filter { it.isNotBlank() }
        var speed: Int? = null
        var rpm: Int? = null
        var gear: Int? = null

        for (i in lines.indices) {
            val line = lines[i]
            val nearby = (line + " " + (lines.getOrNull(i + 1) ?: "")).uppercase()
            val nums = Regex("\\d{1,5}(?:\\.\\d)?").findAll(line).mapNotNull { it.value.toDoubleOrNull() }.toList()
            if (speed == null && (nearby.contains("KM/H") || nearby.contains("KMH"))) {
                speed = nums.firstOrNull { it in 0.0..350.0 }?.toInt()
            }
            if (rpm == null && (nearby.contains("RPM") || nearby.contains("R/MIN"))) {
                val n = nums.firstOrNull { it in 100.0..20000.0 }
                rpm = n?.toInt()
            }
            if (gear == null && (nearby.contains("MARCHA") || nearby.contains("GEAR"))) {
                gear = nums.firstOrNull { it in 0.0..10.0 }?.toInt()
            }
        }
        return Values(speed, rpm, gear)
    }
}
