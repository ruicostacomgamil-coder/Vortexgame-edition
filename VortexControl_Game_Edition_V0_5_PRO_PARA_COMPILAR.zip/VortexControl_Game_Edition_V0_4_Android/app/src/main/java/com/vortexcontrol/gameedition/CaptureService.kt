package com.vortexcontrol.gameedition

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "vortex_capture"
        private const val NOTIFICATION_ID = 44
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: LinearLayout? = null
    private var wm: WindowManager? = null
    private var handler: Handler? = null
    private var lastProcessed = 0L
    private val busy = AtomicBoolean(false)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private lateinit var speedText: TextView
    private lateinit var rpmText: TextView
    private lateinit var gearText: TextView
    private lateinit var stateText: TextView

    override fun onCreate() {
        super.onCreate()
        val thread = HandlerThread("VortexOCR").apply { start() }
        handler = Handler(thread.looper)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification())
        }
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        startProjection()
        return START_NOT_STICKY
    }

    private fun startProjection() {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            if (now - lastProcessed < 700 || !busy.compareAndSet(false, true)) {
                source.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastProcessed = now
            val image = source.acquireLatestImage()
            if (image == null) { busy.set(false); return@setOnImageAvailableListener }
            processImage(image)
        }, handler)
        display = projection?.createVirtualDisplay(
            "VortexControlCapture", w, h, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
    }

    private fun processImage(image: Image) {
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    val parsed = OcrParser.parse(result.text)
                    runOnUiThread { updateOverlay(parsed) }
                }
                .addOnFailureListener { runOnUiThread { stateText.text = "OCR indisponível" } }
                .addOnCompleteListener {
                    bitmap.recycle()
                    busy.set(false)
                }
        } catch (_: Exception) {
            image.close()
            busy.set(false)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 12, 18, 12)
            setBackgroundColor(0xE8171717.toInt())
        }
        stateText = TextView(this).apply { text = "VORTEXCONTROL · OCR AO VIVO"; setTextColor(0xFFFF6666.toInt()); textSize = 10f }
        speedText = TextView(this).apply { text = "-- km/h"; setTextColor(-1); textSize = 25f }
        rpmText = TextView(this).apply { text = "RPM: --"; setTextColor(-1); textSize = 13f }
        gearText = TextView(this).apply { text = "MARCHA: --"; setTextColor(-1); textSize = 13f }
        panel.addView(stateText); panel.addView(speedText); panel.addView(rpmText); panel.addView(gearText)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        panel.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { startX=params.x; startY=params.y; touchX=event.rawX; touchY=event.rawY; true }
                MotionEvent.ACTION_MOVE -> { params.x=startX-(event.rawX-touchX).toInt(); params.y=startY+(event.rawY-touchY).toInt(); wm?.updateViewLayout(panel, params); true }
                else -> true
            }
        }
        overlay = panel
        wm?.addView(panel, params)
    }

    private fun updateOverlay(data: OcrParser.Values) {
        speedText.text = data.speed?.let { "$it km/h" } ?: "-- km/h"
        rpmText.text = "RPM: ${data.rpm?.toString() ?: "--"}"
        gearText.text = "MARCHA: ${data.gear?.toString() ?: "--"}"
        stateText.text = if (data.any) "VORTEXCONTROL · LEITURA AO VIVO" else "VORTEXCONTROL · PROCURANDO INDICADORES"
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "VortexControl captura", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("VortexControl ativo")
            .setContentText("Reconhecimento visual da tela em execução")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
    }

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        recognizer.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
