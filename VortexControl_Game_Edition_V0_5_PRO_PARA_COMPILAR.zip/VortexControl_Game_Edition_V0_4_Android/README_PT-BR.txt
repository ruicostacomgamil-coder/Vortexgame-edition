VORTEXCONTROL GAME EDITION V0.5 PRO — PROJETO-FONTE ANDROID

OBJETIVO
HUD flutuante com leitura visual da tela por OCR enquanto o jogo está aberto.

RECURSOS IMPLEMENTADOS NO CÓDIGO
- Solicita autorização Android para aparecer sobre outros aplicativos.
- Solicita autorização do sistema para captura de tela (MediaProjection).
- Mantém serviço em primeiro plano com tipo mediaProjection.
- Exibe HUD flutuante arrastável.
- Usa Google ML Kit Text Recognition para procurar indicadores visíveis.
- Tenta identificar velocidade (KM/H), RPM e marcha (MARCHA/GEAR).
- Atualiza os componentes da interface na thread principal do Android.

IMPORTANTE — NÃO É APK PRONTO
Este ZIP contém código-fonte Android. Não é possível instalar o ZIP diretamente.
O conversor HTML-to-APK que só oferece permissões de localização, câmera,
arquivos e microfone não consegue compilar nem executar este módulo nativo.
É necessário compilar com Android Studio ou outro ambiente Android compatível.

LIMITAÇÕES DO PRIMEIRO TESTE
- O OCR ainda é genérico e não foi calibrado para o layout específico do Projeto Grau 2.
- Se o jogo mostrar velocímetro/RPM apenas como desenhos ou números sem rótulos
  legíveis, o OCR pode não reconhecer. O próximo passo é ajustar as regiões de leitura
  usando uma captura real do jogo.
- A captura pode consumir bateria e desempenho; o intervalo atual limita a análise
  a aproximadamente uma leitura a cada 700 ms.
- Não lê memória do jogo, não injeta código e não altera o jogo.
- O Android exibe aviso de captura e permite interrompê-la pelo sistema.
- Ainda não foi compilado nem testado no Galaxy A15/Android 16 neste ambiente.

COMO TESTAR QUANDO COMPILADO
1. Abra a pasta como projeto no Android Studio (SDK 35 e JDK 17).
2. Aguarde sincronizar e baixar as dependências Gradle.
3. Use Build > Build APK(s).
4. Instale o APK de debug no Galaxy A15.
5. Abra o VortexControl e toque em ATIVAR CAPTURA E HUD.
6. Autorize aparecer sobre outros apps e a captura de tela.
7. Abra Projeto Grau 2 e observe o HUD.
8. Se os números não aparecerem, envie uma captura da tela do jogo para calibrarmos
   o reconhecimento.

REQUISITOS
- Android mínimo: 8.0 (API 26)
- Compilação: compileSdk 35, Android Gradle Plugin 8.6.1, Kotlin 2.0.21
- Dependência OCR: com.google.mlkit:text-recognition:16.0.1
